# Tuyikunde Furaha Zeno: Portfolio

Personal portfolio website, styled to match my CV. Plain HTML and CSS, no build step.

## Files
- `index.html`: the whole website
- `assets/photo.jpg`: profile photo
- `assets/Tuyikunde_Furaha_Zeno_CV.pdf`: CV (the "Download my CV" button)

## Put it online with GitHub Pages
1. Create a GitHub account and click **New repository**.
2. Name it `your-username.github.io` (for a site at `https://your-username.github.io`), or any name such as `portfolio`.
3. Set it to **Public** and click **Create repository**.
4. Click **uploading an existing file**, drag in `index.html`, `README.md` and the `assets` folder, then click **Commit changes**.
5. Open **Settings > Pages**. Under **Build and deployment**, choose **Deploy from a branch**, select branch `main` and folder `/ (root)`, then click **Save**.
6. Wait 1 to 2 minutes. Your site appears at the link shown on that page.

## Editing
Open `index.html` on GitHub, click the pencil icon, change the text, then commit. The site updates in a minute or two.
