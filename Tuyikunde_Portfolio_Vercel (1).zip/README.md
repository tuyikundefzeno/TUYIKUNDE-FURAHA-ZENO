# Tuyikunde Furaha Zeno: Portfolio

Static portfolio website (plain HTML and CSS, no build step), ready for Vercel and GitHub Pages.

## Files
- `index.html`: the whole website
- `vercel.json`: Vercel settings (clean URLs, security headers, caching)
- `assets/photo.jpg`: profile photo
- `Tuyikunde_Furaha_Zeno_CV.pdf`: CV used by the "Download CV" buttons (keep it next to `index.html`)

## Deploy on Vercel
1. Put these files in a GitHub repository (index.html must be at the top level, not inside another folder).
2. On vercel.com choose **Add New > Project**, import the repository.
3. Framework Preset: **Other**. Leave Build Command and Output Directory empty. Click **Deploy**.
4. Every commit to `main` redeploys the site automatically.

## Run locally
Open `index.html` in a browser, or run `npx serve .`

## Edit
Change text directly in `index.html`. To swap the photo, replace `assets/photo.jpg` (keep the same name).
